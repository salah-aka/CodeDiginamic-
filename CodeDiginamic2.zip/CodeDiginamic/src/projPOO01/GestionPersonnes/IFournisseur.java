package projPOO01.GestionPersonnes;

import java.util.List;

import projPOO01.GestionAchat.commande;

/**Interface IFournisseur permet de d�finir des m�thodes qui sont propres au Fournisseur
 * @author Salaheddine El Majdoub
 *
 */
public interface IFournisseur {
	public boolean livre();
	public void commande(List<commande> listcommande);
	public boolean isFournisseur();
}
