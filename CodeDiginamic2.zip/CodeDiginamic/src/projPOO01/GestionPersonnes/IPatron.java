package projPOO01.GestionPersonnes;

/**Interface IPatron permet de d�finir des m�thodes qui sont propres au Patron
 * @author Salaheddine El Majdoub
 *
 */
public interface IPatron {
	public void embauche();
	public void paieSalarie();
	public void licencie();
	
}
