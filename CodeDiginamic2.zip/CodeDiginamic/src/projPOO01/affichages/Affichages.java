package projPOO01.affichages;

import java.util.ArrayList;

import projPOO01.Programme;
import projPOO01.GestionPersonnes.Personne;
import projPOO01.Menu.Menus;
import projPOO01.saisie.Saisir;

/**Repr�sente la classe d'affichage avec diff�rents m�thodes 
 * @author Salaheddine El Majdoub 18/03/2020
 *
 */
public class Affichages {

	/**
	 * M�thode d'affichage des diff�rents informations an fonction de la saisie de l'utilisateur
	 */
	public static void Afficher() {
		int choix;
		ArrayList<Personne> listpatron = new ArrayList<Personne>();
		listpatron.add(Saisir.patron);
		
		System.out.println("Taper 1 pour afficher toutes les donn�es");
		System.out.println("Taper 2 pour afficher les salari�s");
		System.out.println("Taper 3 pour afficher les clients");
		System.out.println("Taper 4 pour afficher les fournisseur");
		System.out.println("Taper 5 pour afficher le patron");
		System.out.println("Taper 6 pour retourner au menu");
		
		choix=Menus.sc.nextInt();
		
		switch(choix) {
		case 1 : AfficherCommun(Affichages.GrouperAffichage());
		break;
		case 2 : AfficherCommun(Saisir.listsalarie);
		break;
		case 3 : AfficherCommun(Saisir.listclient);
		break;
		case 4 : AfficherCommun(Saisir.listfournisseur);
		break;
		case 5 : AfficherCommun(listpatron);
		break;
		case 6 : Menus.Menu();
		break;
		default : Afficher();
		break;
		}
	}
	
	/**Methode prend en parametre une list de type Personne et qui affiche ses informations (nom, prenom, adresse, ville, code^Postal) 
	 * @param list
	 */
	public static void AfficherCommun(ArrayList<Personne> list ) {
		for(Personne p:list) {
			System.out.println(p.toString());
		}
	}
	
	/** Mathode qui ajoute dans une liste les informations saisie par l'utilisateur  
	 * @return list
	 */
	public static ArrayList<Personne> GrouperAffichage() {
		ArrayList<Personne> list = new ArrayList<Personne>();
		list.addAll(Saisir.listsalarie);
		list.addAll(Saisir.listclient);
		list.addAll(Saisir.listfournisseur);
		list.add(Saisir.patron);
		
		return list;
	}
	
}
