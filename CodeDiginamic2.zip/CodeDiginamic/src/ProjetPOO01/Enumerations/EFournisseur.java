package ProjetPOO01.Enumerations;

public enum EFournisseur {
	nom,
	prenom,
	adresse,
	ville,
	codepostal,
	idfournisseur
}
