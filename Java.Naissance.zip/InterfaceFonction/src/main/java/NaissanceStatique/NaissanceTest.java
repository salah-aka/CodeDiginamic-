package NaissanceStatique;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;







public class NaissanceTest {
	public static void main(String[] args) throws IOException  { 
		Path path = Paths.get("C:/temp/naissances_depuis_1900.csv");
		List<String> lignes = Files.readAllLines(path);
		List<Naissance> naissance = new ArrayList<>();

		for (int i = 1; i < lignes.size(); i++) {
			String ligne = lignes.get(i);
			
			String[] morceaux = ligne.split(";");
			
            Long annee = Long.parseLong(morceaux[1].trim());
            String stringdate = morceaux[2].trim().substring(0, 4) + "/" + morceaux[2].substring(4, 6) + "/" + morceaux[2].substring(6, 8);
          
            LocalDate date = LocalDate.parse(stringdate, DateTimeFormatter.ofPattern("yyyy/MM/dd"));
            Long nombres = Long.parseLong(morceaux[3].trim());
          
            
            naissance.add(new Naissance(annee, date, nombres));
            
    }
		for (Naissance nais : naissance )
			System.out.println(nais);
		System.out.println("-------------------------------------------- ");
		naissance.stream().filter(e -> e.getAnnee() == 1900).forEach(System.out::println);

		}
	}
		
		
		
//			String[] morceaux = ligne.split(";");
//			String annee = morceaux[1];
//			String dateEvenement = morceaux[2];
//			String nombres = morceaux[3];
//			
//		naissance.add(new Naissance(annee, dateEvenement, nombres));
		


	

		
//	    try { 
//	        // Create an object of file reader 
//	    	File file1 = new File("C:/temp/naissances_depuis_1900.csv");
//	        // class with CSV file as a parameter. 
//	    
//	        FileReader filereader = new FileReader(file1); 
//	        
//	        CSVParser parser = new CSVParserBuilder (). withSeparator (';'). build ();
//	        
//	         create csvReader object and skip first Line 
//	        CSVReader csvReader = new CSVReaderBuilder(filereader) 
//                    .withCSVParser(parser) 
//                    .build(); 
//
//	   
//	        List<String[]> allData = csvReader.readAll();
//	    	List<List<String[]>> listP = Arrays.asList(allData);
//	    	Stream<Naissan
//	        ce> sp = allData.stream();
//	    	sp.forEach(System.out::println);
//	        Stream<String[]> sp = allData.stream();
//	        sp.forEach(System.out::println);
//	        
	    
	       /* System.out.println(allData.listIterator(1));
	       
	       for (int i = 1; i < allData.size(); i++) {
	        	
	    		String[] ligne = allData.get(i);
	    		
				String annee = ligne[0];
	    		
				String DateEvenement = ligne[1];
	    		
				String nombres = ligne[2];
	        	
	    	               // allData.get(i);
	        }
	    		
	    		
	        // print Data 
	        for (String[] row : allData) { 
	            for (String cell : row) { 
	                System.out.print(cell + "\t"); 
	            } 
	            System.out.println(); 
	        } 
	    
//	        	    } */
//	} catch (Exception e) { 
//	        e.printStackTrace(); 
//	    } 
//	}}








