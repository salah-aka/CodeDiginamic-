package NaissanceStatique;


import java.io.File;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;





public class Naissance {
	
	
	
	 protected long annee; 
     protected  LocalDate dateEvenement;
     protected long nombres;
     
     /**constructeur
 	 * @param annee
 	 * @param date
 	 * @param nombres
 	 */
 	public Naissance(long annee, LocalDate date, long nombres) {
 		super();
 		this.annee = annee;
 		this.dateEvenement = date;
 		this.nombres = nombres;
 	}

	public long getAnnee() {
		return annee;
	}

	public void setAnnee(long annee) {
		this.annee = annee;
	}

	public LocalDate getDateEvenement() {
		return dateEvenement;
	}

	public void setDateEvenement(LocalDate dateEvenement) {
		this.dateEvenement = dateEvenement;
	}

	public long getNombres() {
		return nombres;
	}

	public void setNombres(long nombres) {
		this.nombres = nombres;
	}
}
	

